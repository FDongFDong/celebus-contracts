#!/usr/bin/env node
/**
 * Boosting 스트레스 테스트 서명 생성 스크립트
 * EIP-712 서명 기반 배치 부스팅 생성
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import crypto from 'node:crypto';
import {
  encodeAbiParameters,
  encodePacked,
  getAddress,
  keccak256,
  stringToHex,
} from 'viem';
import { createPublicClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';

const USER_KEY_SALT = 0x9999999999999999999999999999999999999999999999999999999999999999n;
const DEFAULT_RPC_URL = 'https://opbnb-testnet-rpc.bnbchain.org';
const DEFAULT_BOOSTING_ADDRESS = '0x0000000000000000000000000000000000000000';
const DEFAULT_TOTAL_BOOSTS = 100;
const DEFAULT_USER_COUNT = 20;
const DEFAULT_MISSION_ID = 1;
const MAX_RECORDS_PER_BATCH = 5000;

// Boosting EIP-712 TypeHash
const BOOST_RECORD_TYPESTRING =
  'BoostRecord(uint256 timestamp,uint256 missionId,uint256 boostingId,address userAddress,uint256 artistId,uint8 boostingWith,uint256 amt)';
const BOOST_RECORD_TYPEHASH = keccak256(stringToHex(BOOST_RECORD_TYPESTRING));

const USER_SIG_TYPES = {
  UserSig: [
    { name: 'user', type: 'address' },
    { name: 'userNonce', type: 'uint256' },
    { name: 'recordHash', type: 'bytes32' },
  ],
};

const BATCH_TYPES = {
  Batch: [
    { name: 'batchNonce', type: 'uint256' },
  ],
};

const RECORD_TUPLE = {
  type: 'tuple[]',
  components: [
    { name: 'timestamp', type: 'uint256' },
    { name: 'missionId', type: 'uint256' },
    { name: 'boostingId', type: 'uint256' },
    { name: 'userAddress', type: 'address' },
    { name: 'userId', type: 'string' },
    { name: 'artistId', type: 'uint256' },
    { name: 'boostingWith', type: 'uint8' },
    { name: 'amt', type: 'uint256' },
  ],
};

const USER_SIG_TUPLE = {
  type: 'tuple[]',
  components: [
    { name: 'user', type: 'address' },
    { name: 'userNonce', type: 'uint256' },
    { name: 'signature', type: 'bytes' },
  ],
};

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const part = argv[i];
    if (!part.startsWith('--')) continue;
    const key = part.slice(2);
    const value = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
    args[key] = value;
  }
  return args;
}

function normalizePrivateKey(value) {
  if (!value) return null;
  let hex = value.trim().toLowerCase();
  if (!hex.startsWith('0x')) hex = `0x${hex}`;
  if (hex.length !== 66) {
    throw new Error('PRIVATE_KEY must be 32 bytes (64 hex chars)');
  }
  return hex;
}

function deriveUserKey(index) {
  const encoded = encodeAbiParameters(
    [{ type: 'uint256' }, { type: 'uint256' }],
    [USER_KEY_SALT, BigInt(index + 1)]
  );
  return keccak256(encoded);
}

function toBigInt(value, label) {
  if (typeof value === 'bigint') return value;
  try {
    return BigInt(value);
  } catch (err) {
    throw new Error(`${label} 값을 BigInt로 변환할 수 없습니다: ${value}`);
  }
}

function hashBoostRecord(record) {
  return keccak256(
    encodeAbiParameters(
      [
        { type: 'bytes32' },
        { type: 'uint256' },
        { type: 'uint256' },
        { type: 'uint256' },
        { type: 'address' },
        { type: 'uint256' },
        { type: 'uint8' },
        { type: 'uint256' },
      ],
      [
        BOOST_RECORD_TYPEHASH,
        record.timestamp,
        record.missionId,
        record.boostingId,
        record.userAddress,
        record.artistId,
        record.boostingWith,
        record.amt,
      ]
    )
  );
}

function encodeRecords(records) {
  return encodeAbiParameters([RECORD_TUPLE], [records]);
}

function encodeUserSigs(sigs) {
  return encodeAbiParameters([USER_SIG_TUPLE], [sigs]);
}

function deriveUserNonce(userIndex, timestamp, salt) {
  const packed = encodePacked(
    ['string', 'uint256', 'uint256', 'uint256'],
    ['userNonce', BigInt(userIndex), timestamp, salt]
  );
  return toBigInt(keccak256(packed), 'userNonce');
}

function randomBatchNonce() {
  const rand = BigInt(`0x${crypto.randomBytes(32).toString('hex')}`);
  return (rand % 1_000_000_000n) + 10_000n;
}

async function resolveChainId(rpcUrl, provided) {
  if (provided) return BigInt(provided);
  if (!rpcUrl) return 5611n;
  try {
    const client = createPublicClient({ transport: http(rpcUrl) });
    const id = await client.getChainId();
    return BigInt(id);
  } catch (err) {
    console.warn('[경고] RPC에서 chainId를 가져오지 못했습니다. 기본값 5611 사용');
    return 5611n;
  }
}

async function main() {
  const cli = parseArgs(process.argv.slice(2));
  const executorKey = normalizePrivateKey(process.env.PRIVATE_KEY || cli.privateKey);
  if (!executorKey) {
    throw new Error('환경변수 PRIVATE_KEY (또는 --privateKey) 를 설정해주세요.');
  }

  const rpcUrl = cli.rpcUrl || process.env.RPC_URL || DEFAULT_RPC_URL;
  const boostingAddress = getAddress(cli.boostingAddress || process.env.BOOSTING_ADDRESS || DEFAULT_BOOSTING_ADDRESS);
  const userCount = Number(cli.userCount || process.env.USER_COUNT || DEFAULT_USER_COUNT);
  const totalBoostsInput = Number(cli.totalBoosts || process.env.TOTAL_BOOSTS || DEFAULT_TOTAL_BOOSTS);
  const perUserBoostsRaw = cli.perUserBoosts ?? process.env.PER_USER_BOOSTS;

  let totalBoosts;
  let boostsPerUser;
  if (perUserBoostsRaw !== undefined) {
    boostsPerUser = Number(perUserBoostsRaw);
    if (!Number.isInteger(boostsPerUser) || boostsPerUser <= 0) {
      throw new Error('--perUserBoosts 는 1 이상의 정수여야 합니다.');
    }
    totalBoosts = boostsPerUser * userCount;
  } else {
    totalBoosts = totalBoostsInput;
    if (totalBoosts % userCount !== 0) {
      throw new Error('totalBoosts % userCount 가 0 이어야 합니다.');
    }
    boostsPerUser = totalBoosts / userCount;
  }

  const missionId = toBigInt(cli.missionId || process.env.MISSION_ID || DEFAULT_MISSION_ID, 'missionId');
  const timestampInput = cli.timestamp || process.env.TIMESTAMP;
  const timestamp = timestampInput ? toBigInt(timestampInput, 'timestamp') : BigInt(Math.floor(Date.now() / 1000));
  const nonceSalt = BigInt('0x' + crypto.randomBytes(16).toString('hex'));
  const randomSalt = BigInt('0x' + crypto.randomBytes(16).toString('hex'));
  const chainId = await resolveChainId(rpcUrl, cli.chainId || process.env.CHAIN_ID);

  if (!Number.isInteger(totalBoosts) || totalBoosts <= 0) {
    throw new Error('TOTAL_BOOSTS 는 1 이상의 정수여야 합니다.');
  }
  if (!Number.isInteger(userCount) || userCount <= 0) {
    throw new Error('USER_COUNT 는 1 이상의 정수여야 합니다.');
  }
  if (totalBoosts > MAX_RECORDS_PER_BATCH) {
    throw new Error(`totalBoosts 는 ${MAX_RECORDS_PER_BATCH} 를 초과할 수 없습니다.`);
  }

  const executorAccount = privateKeyToAccount(executorKey);
  const domain = {
    name: 'Boosting',
    version: '1',
    chainId: Number(chainId),
    verifyingContract: boostingAddress,
  };

  const boostingBase = toBigInt(
    keccak256(encodeAbiParameters([{ type: 'uint256' }, { type: 'uint256' }], [timestamp, missionId])),
    'boostingBase'
  );

  const records = [];
  const userSigs = [];

  for (let u = 0; u < userCount; u++) {
    const userKey = deriveUserKey(u);
    const userAccount = privateKeyToAccount(userKey);

    const boostingIdBase = boostingBase + BigInt(u) + (randomSalt % 1_000_000_000n) + 1n;
    const boostingId = (boostingIdBase % 1_000_000_000n) + 1n;
    const userId = `stress-${u}`;

    for (let j = 0; j < boostsPerUser; j++) {
      // 각 레코드마다 고유한 userNonce 생성 (u * 1000 + j로 구분)
      const userNonce = deriveUserNonce(u * 1000 + j, timestamp, nonceSalt + BigInt(u * 1000 + j + 1));
      const amt = BigInt(100 + j * 10);
      // artistId는 1~10 범위로 순환
      const artistId = BigInt((j % 10) + 1);
      // boostingWith: 0=BP, 1=CELB (번갈아가며)
      const boostingWith = j % 2;
      const record = {
        timestamp,
        missionId,
        boostingId,
        userAddress: userAccount.address,
        userId,
        artistId,
        boostingWith,
        amt,
      };
      const recordHash = hashBoostRecord(record);

      records.push(record);

      // 각 레코드마다 개별 서명 (1:1 서명 방식)
      const signature = await userAccount.signTypedData({
        domain,
        types: USER_SIG_TYPES,
        primaryType: 'UserSig',
        message: {
          user: userAccount.address,
          userNonce,
          recordHash,
        },
      });

      userSigs.push({
        user: userAccount.address,
        userNonce,
        signature,
      });
    }
  }

  const batchNonceInput = cli.batchNonce || process.env.BATCH_NONCE;
  const batchNonce = batchNonceInput ? toBigInt(batchNonceInput, 'batchNonce') : randomBatchNonce();
  const executorSig = await executorAccount.signTypedData({
    domain,
    types: BATCH_TYPES,
    primaryType: 'Batch',
    message: { batchNonce },
  });

  const encodedRecords = encodeRecords(records);
  const encodedUserSigs = encodeUserSigs(userSigs);

  const outputDir = resolve(process.cwd(), 'boosting_demo/stress-artifacts');
  mkdirSync(outputDir, { recursive: true });
  const fileName = cli.file || process.env.STRESS_OUT || 'stress-output.json';
  const outPath = resolve(outputDir, fileName);

  const json = {
    contractType: 'Boosting',
    missionId: Number(missionId),
    totalBoosts,
    userCount,
    batchNonce: Number(batchNonce),
    records: encodedRecords,
    userSigs: encodedUserSigs,
    executorSig,
    metadata: {
      boostingAddress,
      chainId: Number(chainId),
      missionId: Number(missionId),
      timestamp: timestamp.toString(),
    },
  };

  writeFileSync(outPath, JSON.stringify(json, null, 2));
  console.log('✅ Boosting 스트레스 서명 세트 생성 완료');
  console.log(`- BOOSTING_ADDRESS: ${boostingAddress}`);
  console.log(`- 총 부스팅 수: ${totalBoosts} (유저 ${userCount}명, 1인당 ${boostsPerUser}건)`);
  console.log(`- artistId: 1~10 순환, boostingWith: 0=BP/1=CELB 번갈아`);
  const uniqueBoostingIds = [...new Set(records.map((r) => r.boostingId.toString()))];
  const sampleBoostingIds = uniqueBoostingIds.slice(0, 10);
  if (sampleBoostingIds.length > 0) {
    console.log(`- 샘플 boostingId (최대 10개): ${sampleBoostingIds.join(', ')}`);
  }
  console.log(`- 배치 논스: ${batchNonce.toString()}`);
  console.log(`- 출력 파일: ${outPath}`);
}

main().catch((err) => {
  console.error('❌ 생성 중 오류 발생:', err.message ?? err);
  process.exitCode = 1;
});
