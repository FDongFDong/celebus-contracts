#!/usr/bin/env node
/**
 * Boosting 스트레스 테스트 제출 스크립트
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  createWalletClient,
  createPublicClient,
  decodeAbiParameters,
  defineChain,
  getAddress,
  http,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';

const DEFAULT_RPC_URL = 'https://opbnb-testnet-rpc.bnbchain.org';
const DEFAULT_STRESS_FILE = 'boosting_demo/stress-artifacts/stress-output.json';

const RECORD_TUPLE = {
  type: 'tuple[]',
  components: [
    { name: 'timestamp', type: 'uint256' },
    { name: 'missionId', type: 'uint256' },
    { name: 'boostingId', type: 'uint256' },
    { name: 'userAddress', type: 'address' },
    { name: 'userId', type: 'string' },
    { name: 'artistId', type: 'uint256' },
    { name: 'boostingWith', type: 'uint8' },
    { name: 'amt', type: 'uint256' },
  ],
};

const USER_SIG_TUPLE = {
  type: 'tuple[]',
  components: [
    { name: 'user', type: 'address' },
    { name: 'userNonce', type: 'uint256' },
    { name: 'signature', type: 'bytes' },
  ],
};

const BOOSTING_ABI = [
  {
    type: 'function',
    stateMutability: 'nonpayable',
    name: 'submitBatch',
    inputs: [
      { name: 'records', type: 'tuple[]', components: RECORD_TUPLE.components },
      { name: 'userSigs', type: 'tuple[]', components: USER_SIG_TUPLE.components },
      { name: 'batchNonce', type: 'uint256' },
      { name: 'executorSig', type: 'bytes' },
    ],
    outputs: [],
  },
];

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const part = argv[i];
    if (!part.startsWith('--')) continue;
    const key = part.slice(2);
    const value = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
    args[key] = value;
  }
  return args;
}

function normalizePrivateKey(value) {
  if (!value) return null;
  let hex = value.trim().toLowerCase();
  if (!hex.startsWith('0x')) hex = `0x${hex}`;
  if (hex.length !== 66) {
    throw new Error('PRIVATE_KEY must be 32 bytes (64 hex chars)');
  }
  return hex;
}

function toBigInt(value, label) {
  if (!value) return undefined;
  try {
    return BigInt(value);
  } catch (err) {
    throw new Error(`${label} 값을 BigInt로 변환할 수 없습니다: ${value}`);
  }
}

function loadStressFile(filePath) {
  const resolved = resolve(process.cwd(), filePath);
  const raw = readFileSync(resolved, 'utf8');
  const json = JSON.parse(raw);
  return { json, resolved };
}

function decodeRecords(encoded) {
  const [records] = decodeAbiParameters([RECORD_TUPLE], encoded);
  return records.map((r) => ({
    timestamp: BigInt(r.timestamp),
    missionId: BigInt(r.missionId),
    boostingId: BigInt(r.boostingId),
    userAddress: getAddress(r.userAddress),
    userId: r.userId,
    artistId: BigInt(r.artistId),
    boostingWith: Number(r.boostingWith),
    amt: BigInt(r.amt),
  }));
}

function decodeUserSigs(encoded) {
  const [sigs] = decodeAbiParameters([USER_SIG_TUPLE], encoded);
  return sigs.map((sig) => ({
    user: getAddress(sig.user),
    userNonce: BigInt(sig.userNonce),
    signature: sig.signature,
  }));
}

async function main() {
  const cli = parseArgs(process.argv.slice(2));
  const privateKey = normalizePrivateKey(process.env.PRIVATE_KEY || cli.privateKey);
  if (!privateKey) {
    throw new Error('환경변수 PRIVATE_KEY (또는 --privateKey) 를 설정해주세요.');
  }

  const rpcUrl = cli.rpcUrl || process.env.RPC_URL || DEFAULT_RPC_URL;
  const stressFile = cli.file || process.env.STRESS_FILE || DEFAULT_STRESS_FILE;

  const { json, resolved } = loadStressFile(stressFile);
  const boostingAddress = getAddress(
    cli.boostingAddress || process.env.BOOSTING_ADDRESS || json.metadata?.boostingAddress
  );
  const records = decodeRecords(json.records);
  const userSigs = decodeUserSigs(json.userSigs);
  const batchNonce = BigInt(json.batchNonce);
  const executorSig = json.executorSig;

  const chainId = BigInt(cli.chainId || process.env.CHAIN_ID || json.metadata?.chainId || 5611);
  const gasLimitInput = cli.gas || process.env.GAS_LIMIT;
  const gasBumpPercentInput = cli.gasBumpPercent || process.env.GAS_BUMP_PERCENT;

  const chain = defineChain({
    id: Number(chainId),
    name: 'opBNB Testnet',
    network: 'opbnb-testnet',
    nativeCurrency: { name: 'BNB', symbol: 'BNB', decimals: 18 },
    rpcUrls: { default: { http: [rpcUrl] }, public: { http: [rpcUrl] } },
  });

  const account = privateKeyToAccount(privateKey);
  const client = createWalletClient({ account, chain, transport: http(rpcUrl) });
  const publicClient = createPublicClient({ chain, transport: http(rpcUrl) });

  console.log('== Boosting 스트레스 서명 제출 시작 ==');
  console.log(`파일: ${resolved}`);
  console.log(`목표 컨트랙트: ${boostingAddress}`);
  console.log(`배치 논스: ${batchNonce}`);
  console.log(`총 레코드: ${records.length}, 유저 서명: ${userSigs.length}`);

  let gasLimit;
  if (gasLimitInput) {
    gasLimit = toBigInt(gasLimitInput, 'gas');
  } else {
    const estimate = await publicClient.estimateContractGas({
      account,
      address: boostingAddress,
      abi: BOOSTING_ABI,
      functionName: 'submitBatch',
      args: [records, userSigs, batchNonce, executorSig],
    });
    gasLimit = (estimate * 125n) / 100n;
    console.log(`Estimated gas: ${estimate.toString()} → applying 25% buffer = ${gasLimit.toString()}`);
  }

  let maxFeePerGas;
  let maxPriorityFeePerGas;
  try {
    const feeData = await publicClient.estimateFeesPerGas();
    maxFeePerGas = feeData.maxFeePerGas;
    maxPriorityFeePerGas = feeData.maxPriorityFeePerGas;
  } catch (err) {
    const gasPrice = await publicClient.getGasPrice();
    maxFeePerGas = gasPrice;
    maxPriorityFeePerGas = gasPrice;
  }

  const gasBumpPercent = gasBumpPercentInput ? Number(gasBumpPercentInput) : 0;
  if (gasBumpPercent > 0) {
    const bump = BigInt(100 + gasBumpPercent);
    maxFeePerGas = (maxFeePerGas * bump) / 100n;
    maxPriorityFeePerGas = (maxPriorityFeePerGas * bump) / 100n;
  }

  const hash = await client.writeContract({
    address: boostingAddress,
    abi: BOOSTING_ABI,
    functionName: 'submitBatch',
    args: [records, userSigs, batchNonce, executorSig],
    gas: gasLimit,
    maxFeePerGas,
    maxPriorityFeePerGas,
  });

  console.log('✅ 제출 완료');
  console.log(`txHash: ${hash}`);
  console.log(`opbnbscan: https://testnet.opbnbscan.com/tx/${hash}`);
}

main().catch((err) => {
  console.error('❌ 제출 중 오류 발생:', err.message ?? err);
  process.exitCode = 1;
});
